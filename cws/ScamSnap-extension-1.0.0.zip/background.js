/*
 * ScamSnap extension — background worker.
 *  - keeps the weekly scam list (same file the phone app reads), refreshed every 12 hours
 *  - judges every page the user opens: the address (offline), our server (scam databases, site age, user reports — signed-in
 *    subscribers only, cached per site for 3 days) and what the page shows (content.js)
 *  - tells the page to show the warning, sets the toolbar badge, counts what was stopped, alerts the family guard
 *  - right-click "Check with ScamSnap"
 */
importScripts('lib/domains.js', 'lib/rules.js', 'strings.js', 'sitecheck.js');

var SERVER = 'https://worker-wandering-recipe-c017.scamsnap26.workers.dev';
var RULES_FALLBACK = 'https://raw.githubusercontent.com/ryanjohn052-hue/scamsnap-rules/main/rules.json';
var CACHE_DAYS = 3;
var tabs = {};   // tabId -> { url, site, server, page, verdict }

function store(keys) { return chrome.storage.local.get(keys); }
function save(obj) { return chrome.storage.local.set(obj); }

// ---------- weekly scam list ----------
var remote = { badHosts: [], version: '' };
async function loadRules() {
  var s = await store(['rules', 'rulesAt']);
  if (s.rules) { remote = s.rules; try { MGRules.extend(Object.assign({ v: 1 }, s.rules)); } catch (e) {} }
  return s.rulesAt || 0;
}
async function refreshRules(force) {
  var at = await loadRules();
  if (!force && Date.now() - at < 12 * 3600 * 1000) return;
  var data = null;
  for (var u of [SERVER + '/rules', RULES_FALLBACK]) {
    try { var r = await fetch(u, { cache: 'no-store' }); if (r.ok) { data = await r.json(); break; } } catch (e) {}
  }
  var clean = data && MGRules.validateRemote(data);
  if (!clean) { await save({ rulesAt: Date.now() }); return; }
  MGRules.extend(data);
  remote = { badHosts: clean.badHosts, version: clean.version };
  await save({ rules: clean, rulesAt: Date.now() });
}

// ---------- our server (signed-in subscribers) ----------
async function post(path, body) {
  var s = await store(['token']);
  if (!s.token) return { status: 401, body: {} };
  body.token = s.token;
  try {
    var r = await fetch(SERVER + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    var b = {}; try { b = await r.json(); } catch (e) {}
    if (r.status === 402) await save({ locked: true });
    else if (r.ok) await save({ locked: false });
    return { status: r.status, body: b };
  } catch (e) { return { status: 0, body: {} }; }
}
async function serverCheck(site) {
  if (!site.reg || site.known || site.internal) return null;
  var key = 'sc:' + site.reg, s = await store([key, 'token']);
  if (s[key] && Date.now() - s[key].at < CACHE_DAYS * 86400000) return s[key];
  if (!s.token) return null;
  var origin = 'https://' + site.host + '/';
  var res = await Promise.all([post('/check', { urls: [origin] }), post('/domain', { domains: [site.reg] })]);
  var out = { at: Date.now(), checked: false, db: false, reports: 0, ageDays: null };
  var c = res[0].body && res[0].body.results && res[0].body.results[0];
  if (res[0].status === 200 && c) {
    out.checked = true;
    out.db = !!((c.webRisk && c.webRisk.threats && c.webRisk.threats.length) || (c.urlhaus && c.urlhaus.threats && c.urlhaus.threats.length));
    out.reports = typeof c.userReports === 'number' ? c.userReports : 0;
  }
  var d = res[1].body && res[1].body.results && res[1].body.results[0];
  if (res[1].status === 200 && d && d.created) {
    var t = Date.parse(d.created); if (!isNaN(t)) out.ageDays = Math.floor((Date.now() - t) / 86400000);
  }
  if (out.checked || out.ageDays != null) { var o = {}; o[key] = out; await save(o); }
  return out;
}

// ---------- judging a tab ----------
async function judge(tabId) {
  var st = tabs[tabId]; if (!st) return;
  var v = SSCheck.combine(st.site, st.server, st.page);
  var prev = st.verdict;
  st.verdict = v;
  badge(tabId, v);
  if (v.level === 'danger' || v.level === 'warn') {
    try { await chrome.tabs.sendMessage(tabId, { type: 'verdict', verdict: v }); } catch (e) {}
  }
  if (v.level === 'danger' && (!prev || prev.level !== 'danger')) await counted(st.site.host);
  if (!st.seen && st.site && st.site.reg && !st.site.internal) { st.seen = true; await seenSite(); }
}
function weekStart() { var wk = new Date(); wk.setHours(0, 0, 0, 0); wk.setDate(wk.getDate() - wk.getDay()); return +wk; }
// Every site the user opened this week (for "You're protected" and the weekly summary).
async function seenSite() {
  var s = await store(['checked']), w = weekStart();
  var c = s.checked && s.checked.week === w ? s.checked : { week: w, n: 0 };
  c.n++; await save({ checked: c });
}
function badge(tabId, v) {
  var text = v.level === 'danger' ? '!' : v.level === 'warn' ? '?' : '';
  var color = v.level === 'danger' ? '#ff4f63' : '#ffb020';
  chrome.action.setBadgeText({ tabId: tabId, text: text }).catch(function () {});
  if (text) chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: color }).catch(function () {});
}
// Count what was stopped this week, and tell the family guard (once a day per site).
async function counted(host) {
  var wk = weekStart();
  var s = await store(['blocked', 'famSent']);
  var b = s.blocked && s.blocked.week === wk ? s.blocked : { week: wk, n: 0 };
  b.n++; var fam = s.famSent || {}, day = new Date().toISOString().slice(0, 10);
  var o = { blocked: b, lastBlock: Date.now() };
  if (fam[host] !== day) { fam[host] = day; o.famSent = fam; post('/family/alert', { level: 'high', host: host }); }
  await save(o);
}

async function startTab(tabId, url) {
  await loadRules();
  var site = SSCheck.siteFromUrl(url, remote);
  tabs[tabId] = { url: url, site: site, server: null, page: null, verdict: null };
  await judge(tabId);
  var srv = await serverCheck(site);
  if (tabs[tabId] && tabs[tabId].url === url) { tabs[tabId].server = srv; await judge(tabId); }
}

chrome.webNavigation && chrome.webNavigation.onCommitted.addListener(function (d) { if (d.frameId === 0) startTab(d.tabId, d.url); });
chrome.tabs.onUpdated.addListener(function (tabId, info, tab) {
  if (info.url) startTab(tabId, info.url);
  else if (info.status === 'loading' && tab.url && (!tabs[tabId] || tabs[tabId].url !== tab.url)) startTab(tabId, tab.url);
});
chrome.tabs.onRemoved.addListener(function (tabId) { delete tabs[tabId]; });

chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
  (async function () {
    if (msg.type === 'page' && sender.tab) {
      var id = sender.tab.id;
      if (!tabs[id] || tabs[id].url !== sender.tab.url) await startTab(id, sender.tab.url);
      tabs[id].page = msg.signals; await judge(id);
      reply({ verdict: tabs[id].verdict });
    } else if (msg.type === 'state') {
      var t = tabs[msg.tabId];
      if (!t && msg.url) { await startTab(msg.tabId, msg.url); t = tabs[msg.tabId]; }
      var s = await store(['email', 'token', 'locked', 'blocked', 'checked', 'rules', 'rulesAt', 'lastBlock', 'rateAsked']);
      var w = weekStart();
      reply({ verdict: t && t.verdict, email: s.token ? s.email : null, locked: !!s.locked,
        blocked: s.blocked && s.blocked.week === w ? s.blocked.n : 0, checked: s.checked && s.checked.week === w ? s.checked.n : 0,
        listCount: s.rules && s.rules.badHosts ? s.rules.badHosts.length : 0, listVersion: s.rules && s.rules.version, listAt: s.rulesAt,
        // Ask for a rating after the extension stopped a dangerous site — at most every 4 months, never in exchange for anything.
        askRate: !!s.lastBlock && (!s.rateAsked || Date.now() - s.rateAsked > 120 * 86400000) });
    } else if (msg.type === 'rated') {
      await save({ rateAsked: Date.now() }); reply({ ok: true });
    } else if (msg.type === 'login') {
      try {
        var r = await fetch(SERVER + '/account/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: msg.email, password: msg.password }) });
        var b = await r.json().catch(function () { return {}; });
        if (r.ok && b.token) { await save({ token: b.token, email: msg.email }); reply({ ok: true }); }
        else reply({ ok: false });
      } catch (e) { reply({ ok: false }); }
    } else if (msg.type === 'logout') {
      var s2 = await store(['token']);
      if (s2.token) fetch(SERVER + '/account/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: s2.token }) }).catch(function () {});
      await chrome.storage.local.remove(['token', 'email', 'locked']);
      reply({ ok: true });
    } else if (msg.type === 'proceed' && sender.tab) {
      var p = (await store(['proceed'])).proceed || {};
      p[msg.host] = Date.now(); await save({ proceed: p }); reply({ ok: true });
    } else if (msg.type === 'proceeded') {
      var q = (await store(['proceed'])).proceed || {};
      reply({ yes: !!q[msg.host] && Date.now() - q[msg.host] < 86400000 });
    } else if (msg.type === 'leave' && sender.tab) {
      chrome.tabs.update(sender.tab.id, { url: 'about:blank' }).catch(function () {});
      reply({ ok: true });
    } else if (msg.type === 'analyze') {
      reply(await analyzeText(msg.text));
    }
  })();
  return true;
});

// ---------- checking text (popup box / right-click) ----------
async function analyzeText(text) {
  text = String(text || '').slice(0, 5000);
  var r = MGRules.analyze(text);
  var level = r.level === 'high' ? 'SCAM' : r.level === 'medium' ? 'SUSPICIOUS' : 'CLEAN';
  var rules = MGRules._rules();
  var reasons = r.hits.map(function (h) {
    var rule = rules.filter(function (x) { return x.id === h.id; })[0] || h;
    return rule.label ? { label: rule.label, detail: rule.detail || null } : null;
  }).filter(Boolean).slice(0, 6);
  // Links in the text: same address checks as for pages.
  var urls = (text.match(/\bhttps?:\/\/[^\s<>"']+|\b(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/[^\s<>"']*)?/gi) || []).slice(0, 4);
  for (var u of urls) {
    var site = SSCheck.siteFromUrl(/^https?:/i.test(u) ? u : 'https://' + u, remote);
    var srv = await serverCheck(site);
    var v = SSCheck.combine(site, srv, null);
    v.reasons.forEach(function (x) { reasons.unshift({ k: x.k, v: x.v, host: site.host }); });
    if (v.level === 'danger') level = 'SCAM'; else if (v.level === 'warn' && level === 'CLEAN') level = 'SUSPICIOUS';
  }
  return { level: level, reasons: reasons };
}

function menus() {
  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({ id: 'ss-check', title: SS.t('menu'), contexts: ['selection', 'link'] });
  });
}
chrome.contextMenus.onClicked.addListener(function (info) {
  var text = info.selectionText || info.linkUrl || '';
  chrome.windows.create({ url: 'check.html?text=' + encodeURIComponent(text.slice(0, 4000)), type: 'popup', width: 480, height: 640 });
});

// ---------- weekly summary: Sunday 18:00, "this week ScamSnap checked X sites and stopped Y" ----------
function nextSunday6pm() {
  var d = new Date(); d.setHours(18, 0, 0, 0); d.setDate(d.getDate() + ((7 - d.getDay()) % 7));
  if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 7);
  return d.getTime();
}
async function planWeekly() {
  var a = await chrome.alarms.get('weekly');
  if (!a) chrome.alarms.create('weekly', { when: nextSunday6pm() });
}
async function weeklySummary() {
  var s = await store(['blocked', 'checked']), w = weekStart();
  var c = s.checked && s.checked.week === w ? s.checked.n : 0, b = s.blocked && s.blocked.week === w ? s.blocked.n : 0;
  chrome.alarms.create('weekly', { when: nextSunday6pm() });
  if (!c) return;
  chrome.notifications.create('ss-week', { type: 'basic', iconUrl: 'icons/icon128.png', title: SS.t('wkT'), message: SS.t(b ? 'wkB' : 'wk0', { c: c, s: b }), priority: 0 });
}
chrome.notifications && chrome.notifications.onClicked.addListener(function (id) {
  if (id === 'ss-week') { chrome.notifications.clear(id); chrome.action.openPopup && chrome.action.openPopup().catch(function () {}); }
});

chrome.runtime.onInstalled.addListener(function () { menus(); refreshRules(true); chrome.alarms.create('rules', { periodInMinutes: 720 }); planWeekly(); });
chrome.runtime.onStartup.addListener(function () { menus(); refreshRules(false); planWeekly(); });
chrome.alarms.onAlarm.addListener(function (a) { if (a.name === 'rules') refreshRules(true); else if (a.name === 'weekly') weeklySummary(); });
