/*
 * ScamSnap extension — runs on every page.
 * Reads a few signs from the page (scary "your computer is infected" text with a phone number, shop prices and discounts,
 * password / card fields, "pay with gift cards or crypto"), sends them to the background worker, and shows ScamSnap's
 * warning when the verdict is 'danger' (full page) or 'warn' (a bar at the top). Nothing from the page leaves the computer.
 */
(function () {
  'use strict';
  if (window.top !== window || window.__ssLoaded) return;
  window.__ssLoaded = true;
  var T = window.SS.t, DIR = window.SS.dir;

  var SCARE = [
    /your (computer|pc|device|windows|mac|system) (is|has been|was) (infected|blocked|locked|hacked|compromised|disabled)/i,
    /(virus|malware|trojan|spyware)(es)? (has been |have been )?(detected|found)/i,
    /call (the )?(microsoft|windows|apple|mac|google|amazon|tech(nical)?)? ?support/i,
    /do not (restart|shut ?down|turn off|close) (your|this) (computer|pc|device|page|browser)/i,
    /(error|alert) code ?[:#]? ?#?[a-z0-9]{4,}/i, /(security|firewall|windows defender) (alert|warning)/i,
    /המחשב שלך (נדבק|ננעל|נחסם|נפרץ)|זוהה וירוס|התקשרו? (לתמיכה|למוקד)|אל תכבה את המחשב/,
    /جهازك (مصاب|مقفل|مخترق)|تم (اكتشاف|العثور على) فيروس|اتصل (بالدعم|بالدعم الفني)/,
    /ваш (компьютер|пк|устройство) (заражен|заблокирован|взломан)|обнаружен (вирус|троян)|позвоните в (службу )?поддержк/i,
    /tu (computadora|ordenador|pc|equipo) (está|ha sido) (infectad|bloquead|hackead)|virus detectado|llam[ae] (a|al) (soporte|servicio técnico)/i,
    /votre (ordinateur|pc|appareil) (est|a été) (infecté|bloqué|piraté)|virus détecté|appelez (le|au) (support|service technique)/i
  ];
  var PHONE = /(\+?\d[\d\s().-]{8,}\d|1-8\d\d-\d{3}-\d{4})/;
  var PRICE = /([$€£₪₽¥]\s?\d[\d.,]*|\d[\d.,]*\s?(€|₪|₽|£|\$|usd|eur|ils|rub|mxn|ars|brl))/gi;
  var CART = /(add to (cart|bag|basket)|buy now|checkout|shop now|הוסף?פ? ל(סל|עגלה)|קנ(ה|ו) עכשיו|לקופה|añadir al carrito|comprar ahora|ajouter au panier|acheter maintenant|в корзину|купить сейчас|أضف إلى (السلة|العربة)|اشتر(ِ)? الآن)/i;
  var OFF = /(?:[-−–]\s?(\d{2})\s?%)|(?:(\d{2})\s?%\s*(?:off|discount|הנחה|descuento|de descuento|remise|de réduction|скидк|خصم))|(?:(?:up to|save|הנחה של|עד|hasta|jusqu'à|скидка|خصم)\s*(\d{2})\s?%)/gi;
  var PAY = /(gift ?cards?|itunes cards?|google play cards?|steam cards?|bitcoin|\bbtc\b|\busdt\b|crypto(currency)? (only|payment)|wire transfer only|western union|moneygram|כרטיס(י)? מתנה|ביטקוין|tarjetas? de regalo|cartes? cadeaux?|подарочн\w+ карт|بطاقات? هدايا)/i;

  function signals() {
    var body = document.body; if (!body) return { seen: true };
    var text = (body.innerText || '').slice(0, 30000);
    var scare = SCARE.filter(function (r) { return r.test(text); }).length;
    var prices = (text.match(PRICE) || []).length;
    var maxOff = 0, m; OFF.lastIndex = 0;
    while ((m = OFF.exec(text))) { var n = +(m[1] || m[2] || m[3]); if (n > maxOff && n < 100) maxOff = n; }
    var login = !!document.querySelector('input[type=password], input[autocomplete^="cc-"], input[name*="card" i], input[name*="cvv" i], input[name*="cvc" i]');
    return {
      seen: true,
      tech: scare >= 2 || (scare >= 1 && PHONE.test(text) && /support|תמיכה|soporte|support|поддержк|الدعم/i.test(text)),
      shop: (prices >= 4 && CART.test(text)) || prices >= 12,
      maxOff: maxOff, login: login, pay: PAY.test(text) && /pay|תשלום|pago|paiement|оплат|دفع/i.test(text)
    };
  }

  var shown = null;
  function host() { return location.hostname.replace(/^www\./, ''); }
  function send() {
    try { chrome.runtime.sendMessage({ type: 'page', signals: signals() }, function (r) { if (chrome.runtime.lastError) return; if (r && r.verdict) show(r.verdict); }); } catch (e) {}
  }
  chrome.runtime.onMessage.addListener(function (msg) { if (msg.type === 'verdict') show(msg.verdict); });

  function show(v) {
    if (!v || (v.level !== 'danger' && v.level !== 'warn')) return;
    if (shown) return;
    if (v.level === 'danger') {
      chrome.runtime.sendMessage({ type: 'proceeded', host: host() }, function (r) {
        if (chrome.runtime.lastError) return;
        if (r && r.yes) banner(v); else overlay(v);
      });
    } else banner(v);
  }

  function root() {
    var old = document.getElementById('scamsnap-root'); if (old) old.remove();
    var el = document.createElement('div'); el.id = 'scamsnap-root';
    el.style.cssText = 'all:initial;position:fixed;inset:0 0 auto 0;z-index:2147483647;';
    (document.documentElement || document.body).appendChild(el);
    var sh = el.attachShadow({ mode: 'closed' });
    var font = chrome.runtime.getURL('Rubik.ttf');
    sh.innerHTML = '<style>@font-face{font-family:SSRubik;src:url(' + font + ');font-weight:300 900}' + CSS + '</style>';
    return { el: el, sh: sh };
  }
  var CSS = '*{box-sizing:border-box;margin:0;padding:0;font-family:SSRubik,Arial,sans-serif}' +
    '.ov{position:fixed;inset:0;background:rgba(6,20,51,.93);display:flex;align-items:center;justify-content:center;padding:20px;backdrop-filter:blur(6px)}' +
    '.box{width:min(760px,100%);max-height:100%;overflow:auto;background:linear-gradient(180deg,#14234a,#0a1430);border:2px solid #ff4f63;border-radius:26px;padding:38px 42px;color:#eaf3ff;box-shadow:0 30px 100px rgba(0,0,0,.6)}' +
    '.hd{display:flex;align-items:center;gap:18px;margin-bottom:16px}.hd img{width:72px;height:72px;flex:none}' +
    'h2{font-size:34px;line-height:1.15;color:#ff4f63;font-weight:800}.shop h2{color:#ffc23d}.shop.box{border-color:#ffc23d}' +
    '.k{font-size:15px;color:#9db4d8;margin-top:4px}.host{direction:ltr;unicode-bidi:isolate;font-weight:700;color:#fff}' +
    '.why{background:rgba(255,79,99,.12);border-radius:14px;padding:12px 16px;margin:14px 0;font-size:18px;line-height:1.5}.why div+div{margin-top:4px}' +
    'ul{margin:10px 0 24px;padding-inline-start:24px;font-size:18px;line-height:1.7;color:#dbe7ff}' +
    '.btns{display:flex;flex-wrap:wrap;gap:12px}.b{border:0;cursor:pointer;border-radius:14px;padding:15px 26px;font-size:18px;font-weight:700}' +
    '.p{background:#19e6ff;color:#061433}.s{background:transparent;color:#9db4d8;border:1px solid rgba(255,255,255,.2);font-weight:500;font-size:15px}' +
    '.bar{position:fixed;top:0;left:0;right:0;background:#3d2a08;border-bottom:2px solid #ffc23d;color:#ffe9b5;display:flex;align-items:center;gap:14px;padding:12px 18px;font-size:16px;line-height:1.4;box-shadow:0 6px 24px rgba(0,0,0,.35)}' +
    '.bar.d{background:#4a1622;border-color:#ff4f63;color:#ffd6dc}.bar img{width:30px;height:30px;flex:none}.bar b{color:#fff}.bar .x{margin-inline-start:auto;background:transparent;border:1px solid rgba(255,255,255,.3);color:#fff;border-radius:10px;padding:7px 14px;cursor:pointer;font-size:14px}';

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function reasonsHtml(v) { return v.reasons.map(function (r) { return '<div>• ' + esc(T(r.k, r.v)) + '</div>'; }).join(''); }

  function overlay(v) {
    shown = 'overlay';
    var r = root(), kind = v.kind === 'tech' ? 'tech' : v.kind === 'shop' ? 'shop' : 'danger';
    var title = kind === 'tech' ? T('ovTech') : kind === 'shop' ? T('ovShop') : T('ovDanger');
    var tips = kind === 'tech' ? T('tipsTech') : kind === 'shop' ? T('tipsShop') : T('tipsDanger');
    r.el.style.inset = '0';
    r.sh.innerHTML += '<div class="ov" dir="' + DIR + '"><div class="box ' + (kind === 'shop' ? 'shop' : '') + '">' +
      '<div class="hd"><img src="' + chrome.runtime.getURL('icons/logo.png') + '"><div><h2>' + esc(title) + '</h2><div class="k">' + esc(T('ovSub')) + ' · <span class="host">' + esc(host()) + '</span></div></div></div>' +
      (v.reasons.length ? '<div class="why">' + reasonsHtml(v) + '</div>' : '') +
      '<ul>' + tips.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>' +
      '<div class="btns"><button class="b p" id="leave">' + esc(T('leave')) + '</button><button class="b s" id="go">' + esc(T('proceed')) + '</button></div></div></div>';
    r.sh.getElementById('leave').onclick = function () { try { history.length > 1 ? history.back() : chrome.runtime.sendMessage({ type: 'leave' }); } catch (e) {} setTimeout(function () { chrome.runtime.sendMessage({ type: 'leave' }); }, 600); };
    r.sh.getElementById('go').onclick = function () { chrome.runtime.sendMessage({ type: 'proceed', host: host() }); r.el.remove(); shown = null; banner(v); };
    if (kind === 'tech') calm();
  }
  // Tech-support scam pages beep, go full screen and block the back button: quiet them down.
  function calm() {
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch (e) {}
    try { document.querySelectorAll('audio,video').forEach(function (m) { m.pause(); m.muted = true; }); } catch (e) {}
    try { window.onbeforeunload = null; } catch (e) {}
  }
  function banner(v) {
    shown = 'banner';
    var r = root();
    r.el.style.inset = '0 0 auto 0';
    var first = v.reasons[0] ? T(v.reasons[0].k, v.reasons[0].v) : (v.level === 'danger' ? T('danger') : T('warn'));
    r.sh.innerHTML += '<div class="bar ' + (v.level === 'danger' ? 'd' : '') + '" dir="' + DIR + '"><img src="' + chrome.runtime.getURL('icons/logo.png') + '"><div><b>' + esc(T('bannerWarn')) + '</b> ' + esc(first) + '</div><button class="x" id="x">' + esc(T('close')) + '</button></div>';
    r.sh.getElementById('x').onclick = function () { r.el.remove(); };
  }

  send();
  setTimeout(send, 3000);                       // pages that fill in after loading
  var mo = new MutationObserver(function () { clearTimeout(mo.t); mo.t = setTimeout(send, 1500); });
  try { mo.observe(document.body, { childList: true, subtree: true }); setTimeout(function () { mo.disconnect(); }, 20000); } catch (e) {}
})();
