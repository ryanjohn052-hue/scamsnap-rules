/* ScamSnap extension — result window for "Check with ScamSnap" (right-click or the popup box). */
(function () {
  'use strict';
  var T = SS.t, app = document.getElementById('app');
  document.documentElement.dir = SS.dir; document.documentElement.lang = SS.lang;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var text = new URLSearchParams(location.search).get('text') || '';
  app.innerHTML = '<div class="head"><img src="icons/logo.png" style="width:40px;height:40px"><b style="font-size:20px">' + esc(T('brand')) + '</b></div><div class="quote">' + esc(text) + '</div><div class="muted">' + esc(T('checking')) + '</div>';
  chrome.runtime.sendMessage({ type: 'analyze', text: text }, function (r) {
    r = r || { level: 'CLEAN', reasons: [] };
    var title = { SCAM: T('resScam'), SUSPICIOUS: T('resSusp'), CLEAN: T('resClean') }[r.level];
    app.innerHTML = '<div class="head"><img src="icons/logo.png" style="width:40px;height:40px"><b style="font-size:20px">' + esc(T('brand')) + '</b></div>' +
      '<div class="res ' + r.level + '"><img src="icons/logo.png"><h2>' + esc(title) + '</h2><p>' + esc(T('resAdvice')[r.level]) + '</p></div>' +
      r.reasons.map(function (x) { var L = SS.lang; var title = x.k ? T(x.k, SS.vars(x.v)) : (x.label[L] || x.label.en); var det = x.k ? x.host : (x.detail ? (x.detail[L] || x.detail.en) : ''); return '<div class="why"><b>' + esc(title) + '</b>' + esc(det) + '</div>'; }).join('') +
      '<div class="quote">' + esc(text) + '</div>';
    document.title = 'ScamSnap – ' + title;
  });
})();
