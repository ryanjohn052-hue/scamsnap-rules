/*
 * ScamSnap extension — judging a web address and a page, without going online.
 * Uses MGDomains (lib/domains.js, the same official-brand list as the app).
 *  - siteFromUrl(url, remote): what the address itself says (weekly scam list, brand look-alike, IP address)
 *  - combine(site, server, page): one verdict from the address, the server checks and what is on the page
 * Levels: 'danger' (show the full warning), 'warn' (show a banner), 'safe', 'unknown'.
 */
(function (g) {
  'use strict';
  var D = g.MGDomains;

  // Shops people buy from, that fake shops copy (in addition to the app's brand list). '*' = brand name under any country ending.
  var SHOPS = {
    nike: ['nike.com', '*'], adidas: ['adidas.com', '*'], zara: ['zara.com', '*'], ikea: ['ikea.com', '*'], walmart: ['walmart.com', '*'],
    bestbuy: ['bestbuy.com', 'bestbuy.ca'], lego: ['lego.com'], rayban: ['ray-ban.com'], 'ray-ban': ['ray-ban.com'], samsung: ['samsung.com'],
    dyson: ['dyson.com', '*'], lululemon: ['lululemon.com', '*'], uniqlo: ['uniqlo.com'], sephora: ['sephora.com', '*'], asos: ['asos.com'],
    zalando: ['zalando.com', '*'], decathlon: ['decathlon.com', '*'], primark: ['primark.com'], newbalance: ['newbalance.com', '*'],
    skechers: ['skechers.com', '*'], crocs: ['crocs.com', '*'], converse: ['converse.com', '*'], timberland: ['timberland.com', '*'],
    northface: ['thenorthface.com'], patagonia: ['patagonia.com'], levis: ['levi.com', '*'], gucci: ['gucci.com'], prada: ['prada.com'],
    louisvuitton: ['louisvuitton.com'], rolex: ['rolex.com'], casio: ['casio.com', '*'], stanley: ['stanley1913.com'], yeti: ['yeti.com'],
    shopee: ['shopee.com', '*'], lazada: ['lazada.com', '*'], flipkart: ['flipkart.com'], wish: ['wish.com'], etsy: ['etsy.com'],
    costco: ['costco.com', '*'], homedepot: ['homedepot.com'], lowes: ['lowes.com'], macys: ['macys.com'], kohls: ['kohls.com'],
    castro: ['castro.com'], terminalx: ['terminalx.com'], ksp: ['ksp.co.il'], shufersal: ['shufersal.co.il'], foxhome: ['foxhome.co.il'],
    playstation: ['playstation.com'], xbox: ['xbox.com'], nintendo: ['nintendo.com', '*'], iphone: ['apple.com'], airpods: ['apple.com']
  };
  var NICE = { paypal: 'PayPal', amazon: 'Amazon', aliexpress: 'AliExpress', ebay: 'eBay', apple: 'Apple', netflix: 'Netflix', microsoft: 'Microsoft',
    google: 'Google', facebook: 'Facebook', instagram: 'Instagram', whatsapp: 'WhatsApp', temu: 'Temu', shein: 'Shein', dhl: 'DHL', fedex: 'FedEx',
    nike: 'Nike', adidas: 'Adidas', zara: 'Zara', ikea: 'IKEA', walmart: 'Walmart', lego: 'LEGO', 'ray-ban': 'Ray-Ban', rayban: 'Ray-Ban',
    northface: 'The North Face', louisvuitton: 'Louis Vuitton', homedepot: 'Home Depot', playstation: 'PlayStation', iphone: 'Apple', airpods: 'Apple' };
  // Legitimate sites whose name contains a brand word.
  var OK = ['youtube-nocookie.com', 'ytimg.com', 'googleapis.com', 'googlevideo.com', 'gstatic.com', 'fbcdn.net', 'fbsbx.com', 'nflxvideo.net', 'nflximg.net',
    'paypal-community.com', 'kleinanzeigen.de', 'ebay-kleinanzeigen.de', 'amazontrust.com', 'media-amazon.com', 'ssl-images-amazon.com', 'aboutamazon.com',
    'appleid.cdn-apple.com', 'cdn-apple.com', 'apple-dns.net', 'mzstatic.com', 'microsoftonline.com', 'msftauth.net', 'windowsupdate.com',
    'whatsapp.net', 'netflix.net', 'pypl.com', 'paypalobjects.com', 'aliexpress-media.com', 'aliexpress.us', 'aliexpress.ru', 'adidas-group.com', 'nike.net', 'zara.net', 'inditex.com', 'ikea.net', 'lego.net', 'alicdn.com', 'samsungcloud.com', 'samsungapps.com'];
  // Words fake sites add next to a brand name.
  var LURE = /^(secure|security|login|log|signin|sign|verify|verification|validate|confirm|update|account|accounts|support|help|helpdesk|service|services|customer|care|center|centre|official|online|web|app|pay|payment|payments|billing|bill|refund|refunds|gift|gifts|promo|promos|bonus|reward|rewards|wallet|auth|kyc|track|tracking|delivery|parcel|post|outlet|outlets|sale|sales|deal|deals|shop|shops|store|stores|offer|offers|discount|discounts|clearance|black|friday|cheap|free|win|winner|prize|claim|unlock|locked|suspend|suspended|alert|notice|recovery|reset|id|team|cs|my|us|uk|eu|global|club|vip|mall|market|direct|express|plus|pro|new|now|today|2024|2025|2026)$/;

  function tokens(host) { return host.split(/[.\-_]+/).filter(Boolean); }
  function allBrands() {
    var out = {};
    for (var b in D.BRANDS) out[b] = { list: D.BRANDS[b], weak: !!(D.WEAK_BRANDS && D.WEAK_BRANDS[b]) };
    for (var s in SHOPS) if (!out[s]) out[s] = { list: SHOPS[s], weak: s.length <= 4 };
    return out;
  }
  var BR = null;
  function officialFor(brand, host) {
    if (D.BRANDS[brand]) return D.brandOfficial(brand, host);
    var list = SHOPS[brand] || [], reg = D.registrable(host);
    if (list.some(function (d) { return d !== '*' && (host === d || host.slice(-(d.length + 1)) === '.' + d || reg === d); })) return true;
    if (list.indexOf('*') !== -1 && D.label(host) === brand) return true;
    return false;
  }
  // Which brand does this address pretend to be? (null if none)
  function lookAlike(host) {
    if (!BR) BR = allBrands();
    if (OK.some(function (d) { return host === d || host.slice(-(d.length + 1)) === '.' + d; })) return null;
    if (D.officialBrand(host) || D.isGov(host) || D.isPopular(host)) return null;
    var tk = tokens(host.replace(/\.[a-z]{2,}$/, '')), hasLure = tk.some(function (t) { return LURE.test(t); });
    for (var b in BR) {
      var key = b.replace(/-/g, '');
      if (officialFor(b, host)) return null;
      var hit = tk.some(function (t) {
        if (t === b || t === key) return true;
        if (BR[b].weak || key.length < 5) return false;
        // "amazondeals", "paypalsecure", "secure-paypal" glued together
        if (t.indexOf(key) === 0 && LURE.test(t.slice(key.length))) return true;
        if (t.slice(-key.length) === key && LURE.test(t.slice(0, t.length - key.length))) return true;
        return false;
      });
      if (!hit) continue;
      if (BR[b].weak && !hasLure) continue;
      return { name: NICE[b] || (b.charAt(0).toUpperCase() + b.slice(1)), key: b };
    }
    return null;
  }

  function onList(host, bad) {
    return (bad || []).some(function (b) { return host === b || host.slice(-(b.length + 1)) === '.' + b; });
  }

  function siteFromUrl(url, remote) {
    var u; try { u = new URL(url); } catch (e) { return { level: 'unknown', internal: true, reasons: [] }; }
    if (!/^https?:$/.test(u.protocol)) return { level: 'unknown', internal: true, reasons: [] };
    var host = D.cleanHost(u.hostname), reg = D.registrable(host);
    var out = { host: host, reg: reg, level: 'unknown', reasons: [], kind: '' };
    if (/^(localhost|127\.|10\.|192\.168\.)/.test(host)) { out.internal = true; return out; }
    out.known = D.isKnownOfficial(host);
    if (onList(host, remote && remote.badHosts)) { out.level = 'danger'; out.kind = 'list'; out.reasons.push({ k: 'r_list' }); return out; }
    if (out.known) { out.level = 'safe'; return out; }
    var b = lookAlike(host);
    if (b) { out.level = 'danger'; out.kind = 'brand'; out.reasons.push({ k: 'r_brand', v: { b: b.name, bk: b.key } }); return out; }
    if (D.isIp(host)) { out.ip = true; out.reasons.push({ k: 'r_ip' }); }
    return out;
  }

  // site: siteFromUrl(); server: {db:bool, reports:n, ageDays:n|null}; page: content-script signals
  function combine(site, server, page) {
    var v = { level: site.level, kind: site.kind, reasons: site.reasons.slice(), host: site.host };
    if (site.internal) return v;
    server = server || {}; page = page || {};
    function add(k, vars) { if (!v.reasons.some(function (r) { return r.k === k; })) v.reasons.push({ k: k, v: vars }); }
    function up(level, kind) {
      var rank = { unknown: 0, safe: 1, warn: 2, danger: 3 };
      if (rank[level] > rank[v.level]) { v.level = level; v.kind = kind; }
    }
    if (server.db) { add('r_db'); up('danger', 'db'); }
    if (server.reports >= 3) { add('r_reports', { n: server.reports }); up(server.reports >= 10 ? 'danger' : 'warn', 'reports'); }
    if (page.tech) { add('r_tech'); up('danger', 'tech'); }
    if (site.known) return v;          // the brand's own site: page content does not change the verdict (beyond the checks above)
    var young = server.ageDays != null && server.ageDays < 45;
    if (young) add('r_new', { d: Math.max(1, server.ageDays) });
    if (page.pay) add('r_pay');
    if (page.shop && page.maxOff >= 60) add(young ? 'r_shop' : 'r_deal', { p: page.maxOff });
    if (page.login && (young || site.ip)) add('r_login');
    // Fake shop: brand-new shop with huge discounts, or asking for gift cards / crypto.
    if (page.shop && young && page.maxOff >= 60) up('danger', 'shop');
    else if (page.shop && page.pay) up('danger', 'shop');
    else if (page.login && site.ip) up('danger', 'login');
    else if (young && (page.shop || page.login)) up('warn', page.shop ? 'shop' : 'login');
    else if (page.pay || (page.shop && page.maxOff >= 80)) up('warn', 'shop');
    if (v.level === 'unknown' && (server.checked || page.seen)) v.level = 'safe';
    return v;
  }

  g.SSCheck = { siteFromUrl: siteFromUrl, combine: combine, lookAlike: lookAlike };
})(typeof window !== 'undefined' ? window : globalThis);
