/* ScamSnap extension — UI texts. Language = the browser's language (he/ar/ru/es/fr), English otherwise. */
(function (g) {
  'use strict';
  var S = {
    en: {
      dir: 'ltr', brand: 'ScamSnap', tagline: 'Check before you click',
      on: 'Protection on', checking: 'Checking…', safe: 'Looks OK', warn: 'Be careful', danger: 'Dangerous site', unknown: 'Not checked', internal: 'Browser page',
      siteIs: 'This site', blockedWeek: 'Blocked this week: {n}', listDate: 'Scam list updated: {d}',
      loginTitle: 'Sign in to ScamSnap', loginHint: 'Same account as the phone app. Without signing in, the built-in checks still work.', email: 'Email', password: 'Password', loginBtn: 'Sign in', logout: 'Sign out', loginErr: 'Wrong email or password', signedAs: 'Signed in: {e}',
      needSub: 'Checking sites against the global scam databases needs an active ScamSnap subscription. The built-in checks work without it.',
      checkPh: 'Paste a message, email or link…', checkBtn: 'Check', openApp: 'Open the ScamSnap app',
      r_brand: 'It pretends to be {b}, but this is not {b}\'s real address.', r_list: 'It is on the ScamSnap scam list (updated weekly).', r_db: 'It is flagged as dangerous in the global scam databases.',
      r_deal: 'Unrealistic discounts (up to {p}% off) — a common sign of a fake shop.',
      r_new: 'The site was created only {d} days ago.', r_shop: 'A brand-new shop with unrealistic discounts (up to {p}% off).', r_login: 'The page asks for a password or card details.',
      r_tech: 'The page scares you that your computer is "infected" and asks you to call support.', r_ip: 'The address is a number (IP), not a name.', r_pay: 'It asks you to pay with gift cards, crypto or a direct transfer.', r_reports: '{n} ScamSnap users reported this site.',
      ovDanger: 'Stop! This site is dangerous', ovTech: 'Stop! This is a "tech support" scam', ovShop: 'Careful: this looks like a fake shop', ovSub: 'ScamSnap stopped this page',
      tipsTech: ['Your computer is not infected. It is just a web page.', 'Do not call the number on the page.', 'Do not install anything they ask you to.'],
      tipsDanger: ['Do not type passwords or card details here.', 'Do not download anything from this site.', 'If you got the link in a message, delete it.'],
      tipsShop: ['Buy from the brand\'s official site or a store you know.', 'Never pay by bank transfer, gift card or crypto.', 'A real 90% discount on new products almost never exists.'],
      leave: 'Leave this site safely', proceed: 'I understand the risk, continue', bannerWarn: 'Careful:', close: 'Close',
      menu: 'Check with ScamSnap', resScam: 'Scam detected', resSusp: 'Suspicious', resClean: 'No scam signs found', resAdvice: { SCAM: 'Don\'t click, don\'t pay and don\'t share any details.', SUSPICIOUS: 'Be careful. Check with the sender through another way before you act.', CLEAN: 'We found no scam signs. Still, never share codes or passwords.' },
      famSent: 'Your family member was notified.',
      crOn: 'You\'re protected', crSub: 'Every site you open is checked', crChecked: 'sites checked this week', crStopped: 'dangerous sites stopped', crList: 'scam sites on the list', chSites: 'Site check', chFam: 'Family guard', chList: 'List updated {d}', rateQ: 'Did ScamSnap protect you? A quick rating helps others find us.', rateBtn: 'Rate ScamSnap ⭐', rateNo: 'Not now', wkT: 'Your week with ScamSnap', wkB: '{c} sites checked, {s} dangerous sites stopped. You\'re protected 🛡️', wk0: '{c} sites checked this week, nothing dangerous. You\'re protected 🛡️'
    },
    he: {
      dir: 'rtl', brand: 'בודק הונאות', tagline: 'בודקים לפני שלוחצים',
      on: 'הגנה פעילה', checking: 'בודק…', safe: 'נראה תקין', warn: 'זהירות', danger: 'אתר מסוכן', unknown: 'לא נבדק', internal: 'דף של הדפדפן',
      siteIs: 'האתר הזה', blockedWeek: 'נחסמו השבוע: {n}', listDate: 'רשימת ההונאות עודכנה: {d}',
      loginTitle: 'התחברות ל-ScamSnap', loginHint: 'אותו חשבון כמו באפליקציה בטלפון. גם בלי להתחבר, הבדיקות המובנות עובדות.', email: 'אימייל', password: 'סיסמה', loginBtn: 'התחברות', logout: 'התנתקות', loginErr: 'אימייל או סיסמה שגויים', signedAs: 'מחובר: {e}',
      needSub: 'בדיקת אתרים במאגרי ההונאות העולמיים דורשת מנוי פעיל ל-ScamSnap. הבדיקות המובנות עובדות גם בלי.',
      checkPh: 'הדביקו הודעה, מייל או קישור…', checkBtn: 'בדיקה', openApp: 'פתיחת אפליקציית ScamSnap',
      r_brand: 'האתר מנסה להיראות כמו {b}, אבל זו לא הכתובת הרשמית שלו.', r_list: 'האתר נמצא ברשימת ההונאות של ScamSnap (מתעדכנת כל שבוע).', r_db: 'האתר מסומן כמסוכן במאגרי ההונאות העולמיים.',
      r_deal: 'הנחות לא הגיוניות (עד {p}%) – סימן נפוץ לחנות מזויפת.',
      r_new: 'האתר נפתח לפני {d} ימים בלבד.', r_shop: 'חנות חדשה עם הנחות לא הגיוניות (עד {p}%).', r_login: 'הדף מבקש סיסמה או פרטי כרטיס.',
      r_tech: 'הדף מפחיד שהמחשב "נדבק" ומבקש להתקשר לתמיכה.', r_ip: 'כתובת האתר היא מספר (IP) ולא שם.', r_pay: 'מבקשים לשלם בכרטיסי מתנה, קריפטו או העברה ישירה.', r_reports: '{n} משתמשי ScamSnap דיווחו על האתר הזה.',
      ovDanger: 'עצרו! האתר הזה מסוכן', ovTech: 'עצרו! זו הונאת "תמיכה טכנית"', ovShop: 'זהירות: זה נראה כמו חנות מזויפת', ovSub: 'ScamSnap עצר את הדף הזה',
      tipsTech: ['המחשב שלכם לא נדבק. זה רק דף אינטרנט.', 'אל תתקשרו למספר שמופיע בדף.', 'אל תתקינו שום תוכנה שמבקשים מכם.'],
      tipsDanger: ['אל תקלידו כאן סיסמה או פרטי כרטיס.', 'אל תורידו שום דבר מהאתר הזה.', 'אם קיבלתם את הקישור בהודעה, מחקו אותה.'],
      tipsShop: ['קנו באתר הרשמי של המותג או בחנות שאתם מכירים.', 'לעולם אל תשלמו בהעברה בנקאית, כרטיס מתנה או קריפטו.', 'הנחה אמיתית של 90% על מוצרים חדשים כמעט לא קיימת.'],
      leave: 'יציאה מהאתר בבטחה', proceed: 'אני מבין את הסיכון, להמשיך', bannerWarn: 'זהירות:', close: 'סגירה',
      menu: 'בדיקה ב-ScamSnap', resScam: 'זוהתה הונאה', resSusp: 'חשוד', resClean: 'לא נמצאו סימני הונאה', resAdvice: { SCAM: 'אל תלחצו, אל תשלמו ואל תמסרו פרטים.', SUSPICIOUS: 'זהירות. בדקו מול השולח בדרך אחרת לפני שאתם עושים משהו.', CLEAN: 'לא מצאנו סימני הונאה. ובכל זאת, אל תמסרו קודים או סיסמאות.' },
      famSent: 'בן המשפחה שלכם קיבל התראה.',
      crOn: 'אתה מוגן', crSub: 'כל אתר שאתם פותחים נבדק', crChecked: 'אתרים נבדקו השבוע', crStopped: 'אתרים מסוכנים נעצרו', crList: 'אתרי הונאה ברשימה', chSites: 'בדיקת אתרים', chFam: 'מגן משפחתי', chList: 'הרשימה עודכנה {d}', rateQ: 'ScamSnap שמר עליכם? דירוג קצר עוזר לאחרים למצוא אותנו.', rateBtn: 'לדרג את ScamSnap ⭐', rateNo: 'לא עכשיו', wkT: 'השבוע שלך עם ScamSnap', wkB: '{c} אתרים נבדקו, {s} אתרים מסוכנים נעצרו. אתה מוגן 🛡️', wk0: '{c} אתרים נבדקו השבוע, שום דבר מסוכן. אתה מוגן 🛡️'
    },
    ar: {
      dir: 'rtl', brand: 'ScamSnap', tagline: 'افحص قبل أن تنقر',
      on: 'الحماية مفعّلة', checking: 'جارٍ الفحص…', safe: 'يبدو سليماً', warn: 'انتبه', danger: 'موقع خطير', unknown: 'لم يُفحص', internal: 'صفحة المتصفح',
      siteIs: 'هذا الموقع', blockedWeek: 'تم الحظر هذا الأسبوع: {n}', listDate: 'آخر تحديث لقائمة الاحتيال: {d}',
      loginTitle: 'تسجيل الدخول إلى ScamSnap', loginHint: 'نفس حساب تطبيق الهاتف. الفحوص المدمجة تعمل حتى بدون تسجيل الدخول.', email: 'البريد الإلكتروني', password: 'كلمة المرور', loginBtn: 'دخول', logout: 'خروج', loginErr: 'البريد أو كلمة المرور غير صحيحة', signedAs: 'مسجّل: {e}',
      needSub: 'فحص المواقع في قواعد بيانات الاحتيال العالمية يتطلب اشتراكاً فعالاً في ScamSnap. الفحوص المدمجة تعمل بدونه.',
      checkPh: 'الصق رسالة أو بريداً أو رابطاً…', checkBtn: 'فحص', openApp: 'فتح تطبيق ScamSnap',
      r_brand: 'الموقع ينتحل صفة {b}، لكن هذا ليس العنوان الرسمي لـ {b}.', r_list: 'الموقع موجود في قائمة الاحتيال لدى ScamSnap (تُحدَّث أسبوعياً).', r_db: 'الموقع مصنّف كخطير في قواعد بيانات الاحتيال العالمية.',
      r_deal: 'خصومات غير منطقية (حتى {p}%) – علامة شائعة على متجر مزيف.',
      r_new: 'تم إنشاء الموقع قبل {d} أيام فقط.', r_shop: 'متجر جديد بخصومات غير منطقية (حتى {p}%).', r_login: 'الصفحة تطلب كلمة مرور أو بيانات بطاقة.',
      r_tech: 'الصفحة تخيفك بأن جهازك "مصاب" وتطلب الاتصال بالدعم.', r_ip: 'عنوان الموقع رقم (IP) وليس اسماً.', r_pay: 'يطلبون الدفع ببطاقات هدايا أو عملات رقمية أو تحويل مباشر.', r_reports: 'أبلغ {n} من مستخدمي ScamSnap عن هذا الموقع.',
      ovDanger: 'توقف! هذا الموقع خطير', ovTech: 'توقف! هذا احتيال "دعم فني"', ovShop: 'انتبه: يبدو متجراً مزيفاً', ovSub: 'أوقف ScamSnap هذه الصفحة',
      tipsTech: ['جهازك غير مصاب. هذه مجرد صفحة إنترنت.', 'لا تتصل بالرقم الظاهر في الصفحة.', 'لا تثبّت أي برنامج يطلبونه منك.'],
      tipsDanger: ['لا تكتب هنا كلمة مرور أو بيانات بطاقة.', 'لا تنزّل أي شيء من هذا الموقع.', 'إذا وصلك الرابط في رسالة، احذفها.'],
      tipsShop: ['اشترِ من الموقع الرسمي للعلامة أو من متجر تعرفه.', 'لا تدفع أبداً بتحويل بنكي أو بطاقة هدايا أو عملات رقمية.', 'خصم حقيقي 90% على منتجات جديدة شبه غير موجود.'],
      leave: 'مغادرة الموقع بأمان', proceed: 'أفهم الخطر، متابعة', bannerWarn: 'انتبه:', close: 'إغلاق',
      menu: 'فحص بـ ScamSnap', resScam: 'تم اكتشاف احتيال', resSusp: 'مشبوه', resClean: 'لم نجد علامات احتيال', resAdvice: { SCAM: 'لا تضغط ولا تدفع ولا تعطِ أي تفاصيل.', SUSPICIOUS: 'انتبه. تحقق من المرسل بطريقة أخرى قبل أن تفعل أي شيء.', CLEAN: 'لم نجد علامات احتيال. ومع ذلك لا تعطِ رموزاً أو كلمات مرور.' },
      famSent: 'تم إشعار فرد عائلتك.',
      crOn: 'أنت محمي', crSub: 'يتم فحص كل موقع تفتحه', crChecked: 'موقعًا تم فحصه هذا الأسبوع', crStopped: 'موقعًا خطيرًا تم إيقافه', crList: 'موقع احتيال في القائمة', chSites: 'فحص المواقع', chFam: 'حماية العائلة', chList: 'تحديث القائمة {d}', rateQ: 'هل حماك ScamSnap؟ تقييم سريع يساعد الآخرين في العثور علينا.', rateBtn: 'قيّم ScamSnap ⭐', rateNo: 'ليس الآن', wkT: 'أسبوعك مع ScamSnap', wkB: 'تم فحص {c} موقعًا وإيقاف {s} موقعًا خطيرًا. أنت محمي 🛡️', wk0: 'تم فحص {c} موقعًا هذا الأسبوع ولا شيء خطير. أنت محمي 🛡️'
    },
    ru: {
      dir: 'ltr', brand: 'ScamSnap', tagline: 'Проверь, прежде чем нажать',
      on: 'Защита включена', checking: 'Проверяем…', safe: 'Выглядит нормально', warn: 'Осторожно', danger: 'Опасный сайт', unknown: 'Не проверено', internal: 'Страница браузера',
      siteIs: 'Этот сайт', blockedWeek: 'Заблокировано за неделю: {n}', listDate: 'Список мошенников обновлён: {d}',
      loginTitle: 'Вход в ScamSnap', loginHint: 'Тот же аккаунт, что и в приложении на телефоне. Встроенные проверки работают и без входа.', email: 'Эл. почта', password: 'Пароль', loginBtn: 'Войти', logout: 'Выйти', loginErr: 'Неверная почта или пароль', signedAs: 'Вход: {e}',
      needSub: 'Проверка сайтов по мировым базам мошенников требует активной подписки ScamSnap. Встроенные проверки работают и без неё.',
      checkPh: 'Вставьте сообщение, письмо или ссылку…', checkBtn: 'Проверить', openApp: 'Открыть приложение ScamSnap',
      r_brand: 'Сайт выдаёт себя за {b}, но это не официальный адрес {b}.', r_list: 'Сайт есть в списке мошенников ScamSnap (обновляется каждую неделю).', r_db: 'Сайт отмечен как опасный в мировых базах мошенников.',
      r_deal: 'Нереальные скидки (до {p}%) — частый признак поддельного магазина.',
      r_new: 'Сайт создан всего {d} дн. назад.', r_shop: 'Совсем новый магазин с нереальными скидками (до {p}%).', r_login: 'Страница просит пароль или данные карты.',
      r_tech: 'Страница пугает, что компьютер «заражён», и просит позвонить в поддержку.', r_ip: 'Адрес сайта — число (IP), а не имя.', r_pay: 'Просят оплатить подарочными картами, криптовалютой или прямым переводом.', r_reports: '{n} пользователей ScamSnap пожаловались на этот сайт.',
      ovDanger: 'Стоп! Этот сайт опасен', ovTech: 'Стоп! Это мошенничество «техподдержки»', ovShop: 'Осторожно: похоже на поддельный магазин', ovSub: 'ScamSnap остановил эту страницу',
      tipsTech: ['Ваш компьютер не заражён. Это просто веб-страница.', 'Не звоните по номеру на странице.', 'Ничего не устанавливайте по их просьбе.'],
      tipsDanger: ['Не вводите здесь пароли и данные карты.', 'Ничего не скачивайте с этого сайта.', 'Если ссылка пришла в сообщении — удалите его.'],
      tipsShop: ['Покупайте на официальном сайте бренда или в знакомом магазине.', 'Никогда не платите переводом, подарочной картой или криптовалютой.', 'Настоящей скидки 90% на новые товары почти не бывает.'],
      leave: 'Безопасно уйти с сайта', proceed: 'Я понимаю риск, продолжить', bannerWarn: 'Осторожно:', close: 'Закрыть',
      menu: 'Проверить в ScamSnap', resScam: 'Обнаружено мошенничество', resSusp: 'Подозрительно', resClean: 'Признаков мошенничества нет', resAdvice: { SCAM: 'Не нажимайте, не платите и не сообщайте данные.', SUSPICIOUS: 'Осторожно. Проверьте отправителя другим способом, прежде чем что-то делать.', CLEAN: 'Признаков мошенничества нет. Но никогда не сообщайте коды и пароли.' },
      famSent: 'Ваш родственник получил уведомление.',
      crOn: 'Вы под защитой', crSub: 'Каждый открытый сайт проверяется', crChecked: 'сайтов проверено за неделю', crStopped: 'опасных сайтов остановлено', crList: 'мошеннических сайтов в списке', chSites: 'Проверка сайтов', chFam: 'Семейная защита', chList: 'Список обновлён {d}', rateQ: 'ScamSnap вас защитил? Короткая оценка поможет другим найти нас.', rateBtn: 'Оценить ScamSnap ⭐', rateNo: 'Не сейчас', wkT: 'Ваша неделя с ScamSnap', wkB: 'Проверено сайтов: {c}, остановлено опасных: {s}. Вы под защитой 🛡️', wk0: 'Проверено сайтов за неделю: {c}, ничего опасного. Вы под защитой 🛡️'
    },
    es: {
      dir: 'ltr', brand: 'ScamSnap', tagline: 'Comprueba antes de hacer clic',
      on: 'Protección activa', checking: 'Revisando…', safe: 'Parece correcto', warn: 'Cuidado', danger: 'Sitio peligroso', unknown: 'Sin revisar', internal: 'Página del navegador',
      siteIs: 'Este sitio', blockedWeek: 'Bloqueados esta semana: {n}', listDate: 'Lista de estafas actualizada: {d}',
      loginTitle: 'Inicia sesión en ScamSnap', loginHint: 'La misma cuenta que en la app del teléfono. Las revisiones integradas funcionan también sin sesión.', email: 'Correo', password: 'Contraseña', loginBtn: 'Entrar', logout: 'Cerrar sesión', loginErr: 'Correo o contraseña incorrectos', signedAs: 'Sesión: {e}',
      needSub: 'Revisar sitios en las bases mundiales de estafas requiere una suscripción activa de ScamSnap. Las revisiones integradas funcionan sin ella.',
      checkPh: 'Pega un mensaje, correo o enlace…', checkBtn: 'Revisar', openApp: 'Abrir la app ScamSnap',
      r_brand: 'Se hace pasar por {b}, pero no es la dirección oficial de {b}.', r_list: 'Está en la lista de estafas de ScamSnap (se actualiza cada semana).', r_db: 'Está marcado como peligroso en las bases mundiales de estafas.',
      r_deal: 'Descuentos irreales (hasta {p}%): una señal común de tienda falsa.',
      r_new: 'El sitio se creó hace solo {d} días.', r_shop: 'Tienda nueva con descuentos irreales (hasta {p}%).', r_login: 'La página pide una contraseña o datos de tarjeta.',
      r_tech: 'La página te asusta con que tu computadora está "infectada" y te pide llamar a soporte.', r_ip: 'La dirección es un número (IP), no un nombre.', r_pay: 'Piden pagar con tarjetas de regalo, cripto o transferencia directa.', r_reports: '{n} usuarios de ScamSnap denunciaron este sitio.',
      ovDanger: '¡Alto! Este sitio es peligroso', ovTech: '¡Alto! Es una estafa de "soporte técnico"', ovShop: 'Cuidado: parece una tienda falsa', ovSub: 'ScamSnap detuvo esta página',
      tipsTech: ['Tu computadora no está infectada. Es solo una página web.', 'No llames al número de la página.', 'No instales nada de lo que te pidan.'],
      tipsDanger: ['No escribas aquí contraseñas ni datos de tarjeta.', 'No descargues nada de este sitio.', 'Si recibiste el enlace en un mensaje, bórralo.'],
      tipsShop: ['Compra en el sitio oficial de la marca o en una tienda que conozcas.', 'Nunca pagues por transferencia, tarjeta de regalo o cripto.', 'Un descuento real del 90% en productos nuevos casi no existe.'],
      leave: 'Salir del sitio de forma segura', proceed: 'Entiendo el riesgo, continuar', bannerWarn: 'Cuidado:', close: 'Cerrar',
      menu: 'Revisar con ScamSnap', resScam: 'Estafa detectada', resSusp: 'Sospechoso', resClean: 'No se encontraron señales de estafa', resAdvice: { SCAM: 'No hagas clic, no pagues y no compartas ningún dato.', SUSPICIOUS: 'Cuidado. Verifica con el remitente por otra vía antes de actuar.', CLEAN: 'No encontramos señales de estafa. Aun así, nunca compartas códigos ni contraseñas.' },
      famSent: 'Tu familiar recibió un aviso.',
      crOn: 'Estás protegido', crSub: 'Se revisa cada sitio que abres', crChecked: 'sitios revisados esta semana', crStopped: 'sitios peligrosos detenidos', crList: 'sitios de estafa en la lista', chSites: 'Revisión de sitios', chFam: 'Protección familiar', chList: 'Lista actualizada {d}', rateQ: '¿ScamSnap te protegió? Una valoración rápida ayuda a otros a encontrarnos.', rateBtn: 'Valorar ScamSnap ⭐', rateNo: 'Ahora no', wkT: 'Tu semana con ScamSnap', wkB: '{c} sitios revisados, {s} sitios peligrosos detenidos. Estás protegido 🛡️', wk0: '{c} sitios revisados esta semana, nada peligroso. Estás protegido 🛡️'
    },
    fr: {
      dir: 'ltr', brand: 'ScamSnap', tagline: 'Vérifiez avant de cliquer',
      on: 'Protection active', checking: 'Vérification…', safe: 'Semble correct', warn: 'Prudence', danger: 'Site dangereux', unknown: 'Non vérifié', internal: 'Page du navigateur',
      siteIs: 'Ce site', blockedWeek: 'Bloqués cette semaine : {n}', listDate: 'Liste des arnaques mise à jour : {d}',
      loginTitle: 'Connexion à ScamSnap', loginHint: 'Le même compte que l\'appli mobile. Les vérifications intégrées marchent aussi sans connexion.', email: 'E-mail', password: 'Mot de passe', loginBtn: 'Se connecter', logout: 'Se déconnecter', loginErr: 'E-mail ou mot de passe incorrect', signedAs: 'Connecté : {e}',
      needSub: 'Vérifier les sites dans les bases mondiales d\'arnaques nécessite un abonnement ScamSnap actif. Les vérifications intégrées marchent sans.',
      checkPh: 'Collez un message, un e-mail ou un lien…', checkBtn: 'Vérifier', openApp: 'Ouvrir l\'appli ScamSnap',
      r_brand: 'Le site se fait passer pour {b}, mais ce n\'est pas l\'adresse officielle de {b}.', r_list: 'Le site figure sur la liste d\'arnaques ScamSnap (mise à jour chaque semaine).', r_db: 'Le site est signalé comme dangereux dans les bases mondiales d\'arnaques.',
      r_deal: 'Remises irréalistes (jusqu\'à {p} %) : un signe fréquent de fausse boutique.',
      r_new: 'Le site a été créé il y a seulement {d} jours.', r_shop: 'Boutique toute neuve avec des remises irréalistes (jusqu\'à {p} %).', r_login: 'La page demande un mot de passe ou des données de carte.',
      r_tech: 'La page vous fait peur avec un ordinateur « infecté » et vous demande d\'appeler le support.', r_ip: 'L\'adresse est un numéro (IP), pas un nom.', r_pay: 'On vous demande de payer en cartes cadeaux, crypto ou virement direct.', r_reports: '{n} utilisateurs ScamSnap ont signalé ce site.',
      ovDanger: 'Stop ! Ce site est dangereux', ovTech: 'Stop ! C\'est une arnaque au « support technique »', ovShop: 'Prudence : ça ressemble à une fausse boutique', ovSub: 'ScamSnap a arrêté cette page',
      tipsTech: ['Votre ordinateur n\'est pas infecté. Ce n\'est qu\'une page web.', 'N\'appelez pas le numéro affiché.', 'N\'installez rien de ce qu\'on vous demande.'],
      tipsDanger: ['Ne tapez ici ni mot de passe ni données de carte.', 'Ne téléchargez rien depuis ce site.', 'Si vous avez reçu le lien par message, supprimez-le.'],
      tipsShop: ['Achetez sur le site officiel de la marque ou dans une boutique connue.', 'Ne payez jamais par virement, carte cadeau ou crypto.', 'Une vraie remise de 90 % sur du neuf n\'existe presque jamais.'],
      leave: 'Quitter le site en sécurité', proceed: 'Je comprends le risque, continuer', bannerWarn: 'Prudence :', close: 'Fermer',
      menu: 'Vérifier avec ScamSnap', resScam: 'Arnaque détectée', resSusp: 'Suspect', resClean: 'Aucun signe d\'arnaque', resAdvice: { SCAM: 'Ne cliquez pas, ne payez pas et ne donnez aucune information.', SUSPICIOUS: 'Prudence. Vérifiez auprès de l\'expéditeur par un autre moyen avant d\'agir.', CLEAN: 'Aucun signe d\'arnaque. Ne donnez quand même jamais de codes ni de mots de passe.' },
      famSent: 'Votre proche a été prévenu.',
      crOn: 'Vous êtes protégé', crSub: 'Chaque site que vous ouvrez est vérifié', crChecked: 'sites vérifiés cette semaine', crStopped: 'sites dangereux arrêtés', crList: 'sites d\'arnaque dans la liste', chSites: 'Vérification des sites', chFam: 'Protection familiale', chList: 'Liste mise à jour {d}', rateQ: 'ScamSnap vous a protégé ? Une note rapide aide les autres à nous trouver.', rateBtn: 'Noter ScamSnap ⭐', rateNo: 'Pas maintenant', wkT: 'Votre semaine avec ScamSnap', wkB: '{c} sites vérifiés, {s} sites dangereux arrêtés. Vous êtes protégé 🛡️', wk0: '{c} sites vérifiés cette semaine, rien de dangereux. Vous êtes protégé 🛡️'
    }
  };
  function lang() {
    var l = '';
    try { l = (g.chrome && chrome.i18n && chrome.i18n.getUILanguage()) || ''; } catch (e) {}
    if (!l && g.navigator) l = navigator.language || '';
    l = l.toLowerCase().slice(0, 2);
    if (l === 'iw') l = 'he';
    return S[l] ? l : 'en';
  }
  var L = lang();
  function t(k, vars) {
    var v = (S[L] && S[L][k] !== undefined) ? S[L][k] : S.en[k];
    if (typeof v === 'string' && vars) for (var x in vars) v = v.split('{' + x + '}').join(vars[x]);
    return v;
  }
  // Local names for brands people know by their own language's name.
  var BRAND_NAMES = {
    he: { leumi: 'בנק לאומי', poalim: 'בנק הפועלים', bankhapoalim: 'בנק הפועלים', discount: 'בנק דיסקונט', discountbank: 'בנק דיסקונט', mizrahi: 'מזרחי טפחות', tefahot: 'מזרחי טפחות',
      doar: 'דואר ישראל', israelpost: 'דואר ישראל', isracard: 'ישראכרט', max: 'מקס', cal: 'כאל', bit: 'ביט', paybox: 'פייבוקס', kvish6: 'כביש 6', iec: 'חברת החשמל',
      bezeq: 'בזק', partner: 'פרטנר', cellcom: 'סלקום', pelephone: 'פלאפון', clalit: 'כללית', maccabi: 'מכבי', meuhedet: 'מאוחדת', btl: 'ביטוח לאומי' },
    ar: {}, ru: { sberbank: 'Сбербанк', sber: 'Сбер', tinkoff: 'Т-Банк', vtb: 'ВТБ', alfabank: 'Альфа-Банк', gosuslugi: 'Госуслуги', pochta: 'Почта России' }, es: {}, fr: {}, en: {}
  };
  // Reason values: show a brand by its local name when we have one.
  function vars(v) {
    if (!v || !v.bk) return v;
    var n = (BRAND_NAMES[L] || {})[v.bk];
    return n ? Object.assign({}, v, { b: n }) : v;
  }
  var t0 = t;
  t = function (k, v) { return t0(k, vars(v)); };
  g.SS = { t: t, lang: L, dir: t0('dir'), vars: vars };
})(typeof window !== 'undefined' ? window : globalThis);
