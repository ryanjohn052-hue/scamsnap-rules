/* ScamSnap extension — toolbar popup: this site's verdict, quick text check, sign-in, weekly list status. */
(function () {
  'use strict';
  var T = SS.t, app = document.getElementById('app');
  document.documentElement.dir = SS.dir; document.documentElement.lang = SS.lang;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function send(m) { return new Promise(function (res) { chrome.runtime.sendMessage(m, function (r) { res(r || {}); }); }); }

  async function render() {
    var tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0] || {};
    var st = await send({ type: 'state', tabId: tab.id, url: tab.url });
    var v = st.verdict, host = '';
    try { host = new URL(tab.url).hostname.replace(/^www\./, ''); } catch (e) {}
    var lvl = !v || !/^https?:/.test(tab.url || '') ? 'unknown' : v.level;
    var word = !/^https?:/.test(tab.url || '') ? T('internal') : { danger: T('danger'), warn: T('warn'), safe: T('safe'), unknown: T('checking') }[lvl];
    var reasons = (v && v.reasons || []).map(function (r) { return '<li>• ' + esc(T(r.k, r.v)) + '</li>'; }).join('');
    var d = st.listAt ? new Date(st.listAt).toLocaleDateString(SS.lang, { day: 'numeric', month: 'numeric' }) : '—';
    var nf = function (n) { try { return Number(n || 0).toLocaleString(SS.lang); } catch (e) { return String(n || 0); } };
    var shield = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#2fe39a" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></svg>';
    // "You're protected" — same idea as the phone app's card: what's on and what it did this week.
    var care =
      '<div class="care"><div class="care-h"><span class="care-ic">' + shield + '</span><div><b>' + esc(T('crOn')) + '</b><small>' + esc(T('crSub')) + '</small></div></div>' +
      '<div class="chips"><span>✓ ' + esc(T('chSites')) + '</span>' + (st.email ? '<span>✓ ' + esc(T('chFam')) + '</span>' : '') + '<span>✓ ' + esc(T('chList', { d: d })) + '</span></div>' +
      '<div class="cstats"><div><b class="c">' + nf(st.checked) + '</b><small>' + esc(T('crChecked')) + '</small></div>' +
      '<div><b class="r">' + nf(st.blocked) + '</b><small>' + esc(T('crStopped')) + '</small></div>' +
      '<div><b class="g">' + nf(st.listCount) + '</b><small>' + esc(T('crList')) + '</small></div></div></div>';
    var rate = st.askRate ? '<div class="rate"><div class="muted">' + esc(T('rateQ')) + '</div><div class="row"><button class="btn" id="rateGo">' + esc(T('rateBtn')) + '</button><button class="btn s" id="rateNo">' + esc(T('rateNo')) + '</button></div></div>' : '';
    var acct = (st.email
        ? '<div class="box"><div class="row"><div class="muted" style="flex:1">' + esc(T('signedAs', { e: st.email })) + '</div><button class="btn s" id="out">' + esc(T('logout')) + '</button></div>' + (st.locked ? '<div class="muted">' + esc(T('needSub')) + '</div>' : '') + '</div>'
        : '<div class="box"><h3>' + esc(T('loginTitle')) + '</h3><div class="muted">' + esc(T('loginHint')) + '</div><input id="em" type="email" placeholder="' + esc(T('email')) + '"><input id="pw" type="password" placeholder="' + esc(T('password')) + '"><div class="err" id="err"></div><button class="btn" id="in">' + esc(T('loginBtn')) + '</button></div>');
    // Two columns side by side (a computer screen): left = you're protected + account, right = this site + quick check.
    app.innerHTML =
      '<div class="head"><img src="icons/logo.png"><div><b>' + esc(T('brand')) + '</b><small>' + esc(T('tagline')) + '</small></div></div>' +
      '<div class="cols"><div class="col">' + care + rate + acct + '</div><div class="col">' +
      '<div class="site ' + lvl + '"><div class="lbl">' + esc(T('siteIs')) + '</div><div class="host">' + esc(host) + '</div><div class="v">' + esc(word) + '</div>' + (reasons ? '<ul>' + reasons + '</ul>' : '') + '</div>' +
      '<div class="box"><textarea id="txt" placeholder="' + esc(T('checkPh')) + '"></textarea><button class="btn" id="chk">' + esc(T('checkBtn')) + '</button></div>' +
      '</div></div>';
    document.getElementById('chk').onclick = function () {
      var t = document.getElementById('txt').value.trim(); if (!t) return;
      chrome.windows.create({ url: 'check.html?text=' + encodeURIComponent(t.slice(0, 4000)), type: 'popup', width: 480, height: 640 });
    };
    var rg = document.getElementById('rateGo'), rn = document.getElementById('rateNo');
    if (rg) rg.onclick = async function () { await send({ type: 'rated' }); chrome.tabs.create({ url: 'https://chromewebstore.google.com/detail/' + chrome.runtime.id + '/reviews' }); };
    if (rn) rn.onclick = async function () { await send({ type: 'rated' }); render(); };
    var out = document.getElementById('out'); if (out) out.onclick = async function () { await send({ type: 'logout' }); render(); };
    var inb = document.getElementById('in'); if (inb) inb.onclick = async function () {
      var r = await send({ type: 'login', email: document.getElementById('em').value.trim(), password: document.getElementById('pw').value });
      if (r.ok) render(); else document.getElementById('err').textContent = T('loginErr');
    };
    if (/^https?:/.test(tab.url || '') && (!v || v.level === 'unknown')) setTimeout(render, 1500);
  }
  render();
})();
